import { LightningElement, track } from 'lwc';
import recordingGif from '@salesforce/resourceUrl/recordingProgress';

export default class VoiceRecorderLauncher extends LightningElement {
    @track showPopup = false;
    @track uploadMessage = '';
    @track isUploading = false;
    @track score;
    @track audioUrl;
    @track isCommunity = false;
    @track isPlaying = false; // ✅ Added to show animation while audio plays

    recordingGif = recordingGif;
    mediaRecorder;
    audioChunks = [];
    audioContext;

    connectedCallback() {
        const hostname = window.location.hostname;
        this.isCommunity = hostname.includes('force.com') || hostname.includes('site.com');
    }

    openPopup() {
        this.showPopup = true;
        this.uploadMessage = '';
        this.audioUrl = null;

        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
        }
        if (this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }

        const unlock = document.createElement('audio');
        unlock.src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=';
        unlock.muted = true;
        unlock.autoplay = true;
        unlock.style.display = 'none';
        document.body.appendChild(unlock);
        unlock.play().catch(() => {});

        this.startRecording();
    }

    closePopup() {
        this.showPopup = false;
    }

    stopPropagation(event) {
        event.stopPropagation();
    }

    async startRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: { channelCount: 1, sampleRate: 16000 }
            });
            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];

            this.mediaRecorder.ondataavailable = e => {
                if (e.data.size > 0) this.audioChunks.push(e.data);
            };

            this.mediaRecorder.start();
            console.log('🎙️ Recording started...');
        } catch (err) {
            console.error('❌ Microphone access error:', err);
            this.uploadMessage = '❌ Please allow microphone access.';
        }
    }

    async handleSubmit() {
        if (!this.mediaRecorder || this.mediaRecorder.state === 'inactive') {
            this.uploadMessage = '⚠️ No active recording.';
            return;
        }

        this.isUploading = true;
        this.uploadMessage = '⏳ Processing your recording...';
        await this.stopRecording();
        this.isUploading = false;
    }

    async stopRecording() {
        return new Promise(resolve => {
            this.mediaRecorder.onstop = async () => {
                try {
                    const audioBlob = new Blob(this.audioChunks);
                    const arrayBuffer = await audioBlob.arrayBuffer();
                    const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
                    const wavBlob = await this.audioBufferToWav(audioBuffer);
                    await this.uploadAudioToN8N(wavBlob);
                } catch (err) {
                    console.error('❌ Error processing audio:', err);
                    this.uploadMessage = '❌ Error processing audio.';
                }
                resolve();
            };
            this.mediaRecorder.stop();
            console.log('🛑 Recording stopped');
        });
    }

    async uploadAudioToN8N(wavBlob) {
        const formData = new FormData();
        formData.append('file', wavBlob, 'recording.wav');

        try {
            const response = await fetch('https://aiorchestrator.vcollabetiq.com/webhook/4e30a5b7-6fe9-4ef2-bf69-1eeb1dbe31ee', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) throw new Error('Upload failed');

            const contentType = response.headers.get('content-type') || '';
            if (contentType.includes('application/json')) {
                const result = await response.json();
                this.score = result?.score ?? 0;
                this.uploadMessage = '✅ Uploaded successfully!';

                if (result.audioBase64) {
                    await this.playReturnedAudio(result.audioBase64);
                } else if (result.audioUrl) {
                    await this.playReturnedAudio(result.audioUrl, true);
                } else {
                    this.uploadMessage = '✅ Uploaded (no audio returned).';
                }
            } else if (contentType.includes('audio')) {
                const audioBlob = await response.blob();
                const audioUrl = URL.createObjectURL(audioBlob);
                await this.playReturnedAudio(audioUrl, true);
                this.uploadMessage = '✅ Audio received and playing!';
            } else {
                this.uploadMessage = '✅ Uploaded (no audio returned).';
            }
        } catch (err) {
            console.error('❌ Upload error:', err);
            this.uploadMessage = '❌ Failed to upload recording.';
        } finally {
            this.isUploading = false;
        }
    }

    async playReturnedAudio(audioData, isUrl = false) {
        return new Promise(resolve => {
            try {
                const audioSrc = isUrl ? audioData : 'data:audio/wav;base64,' + audioData;
                this.audioUrl = audioSrc;
                this.isPlaying = true;

                const audio = new Audio(audioSrc);
                audio.autoplay = true;

                audio.onended = () => {
                    console.log('✅ Playback finished');
                    this.isPlaying = false;
                    this.closePopup();
                    resolve();
                };

                audio.play()
                    .then(() => console.log('🎶 Playback started'))
                    .catch(err => {
                        console.warn('⚠️ Autoplay blocked:', err);
                        this.isCommunity = true;
                        this.uploadMessage = '▶️ Tap Play Audio to listen.';
                        this.isPlaying = false;
                        resolve();
                    });
            } catch (e) {
                console.error('❌ Error playing returned audio:', e);
                this.isPlaying = false;
                resolve();
            }
        });
    }

    async audioBufferToWav(audioBuffer) {
        const numberOfChannels = 1;
        const sampleRate = 16000;
        const format = 1;
        const bitDepth = 16;

        let audioData = audioBuffer.sampleRate !== sampleRate
            ? this.resampleAudio(audioBuffer, sampleRate)
            : audioBuffer.getChannelData(0);

        const dataLength = audioData.length * (bitDepth / 8);
        const buffer = new ArrayBuffer(44 + dataLength);
        const view = new DataView(buffer);

        this.writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + dataLength, true);
        this.writeString(view, 8, 'WAVE');
        this.writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, format, true);
        view.setUint16(22, numberOfChannels, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * numberOfChannels * (bitDepth / 8), true);
        view.setUint16(32, numberOfChannels * (bitDepth / 8), true);
        view.setUint16(34, bitDepth, true);
        this.writeString(view, 36, 'data');
        view.setUint32(40, dataLength, true);

        let offset = 44;
        for (let i = 0; i < audioData.length; i++) {
            const s = Math.max(-1, Math.min(1, audioData[i]));
            view.setInt16(offset + i * 2, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        }

        return new Blob([buffer], { type: 'audio/wav' });
    }

    writeString(view, offset, string) {
        for (let i = 0; i < string.length; i++) {
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    }

    resampleAudio(audioBuffer, targetSampleRate) {
        const inputData = audioBuffer.getChannelData(0);
        const inputLength = inputData.length;
        const outputLength = Math.round(inputLength * targetSampleRate / audioBuffer.sampleRate);
        const outputData = new Float32Array(outputLength);
        const ratio = inputLength / outputLength;

        for (let i = 0; i < outputLength; i++) {
            const pos = i * ratio;
            const index = Math.floor(pos);
            const frac = pos - index;
            outputData[i] =
                index + 1 < inputLength
                    ? inputData[index] * (1 - frac) + inputData[index + 1] * frac
                    : inputData[index];
        }
        return outputData;
    }
}